package com.example.trabalhoandroid;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {


    private EditText txtNome;
    private EditText txtCpf;
    private EditText txtItem;
    private EditText txtVlUnit;
    private EditText txtVlTot;
    private EditText txtQtd;
    private EditText txtParcelas;
    private EditText txtCdPedido;
    private TextView tvLsItens;
    private TextView tvParcelas;
    private TextView tvLsParcelas;
    private LinearLayout ltParcelas;
    private Button btnSalvar;
    private Button btnAdd;
    private Button btnCalcular;
    private Button btnProcurar;
    private RadioGroup rgPagamento;
    private RadioButton rbtnVista;
    private RadioButton rbtnPrazo;

    private ArrayList<Item> lsItens = new ArrayList<Item>();
    private ArrayList<Pedido> lsPedidos = new ArrayList<Pedido>();
    private double total = 0.0;

    private double totalFmPagto = 0.0;
    private int idCdPed = 1;
    private int nrParc;

    private boolean vista;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtNome = findViewById(R.id.txtNome);
        txtCpf = findViewById(R.id.txtCpf);
        txtItem = findViewById(R.id.txtItem);
        txtQtd = findViewById(R.id.txtQtd);
        txtVlUnit = findViewById(R.id.txtVlUnit);
        txtVlTot = findViewById(R.id.txtVlTot);
        txtParcelas = findViewById(R.id.edtParcelas);
        txtCdPedido = findViewById(R.id.txtCdPedido);
        ltParcelas = findViewById(R.id.layoutParcelas);
        tvParcelas = findViewById(R.id.tvParcelas);
        tvLsItens = findViewById(R.id.tvLsItens);
        tvLsParcelas = findViewById(R.id.tvLsParcelas);
        btnSalvar = findViewById(R.id.btnSalvar);
        btnAdd = findViewById(R.id.btnAdd);
        btnCalcular = findViewById(R.id.btnCalcular);
        btnProcurar = findViewById(R.id.btnProcurar);

        rgPagamento = findViewById(R.id.radioGroupPagamento);
        rbtnVista = findViewById(R.id.rbtnVista);
        rbtnPrazo = findViewById(R.id.rbtnPrazo);

        rgPagamento.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (checkedId == R.id.rbtnVista) {
                    ltParcelas.setVisibility(View.GONE);
                    tvParcelas.setVisibility(View.GONE);
                    totalFmPagto = total - (total * 0.05);
                    txtVlTot.setText(String.valueOf(totalFmPagto));
                } else if (checkedId == R.id.rbtnPrazo) {
                    ltParcelas.setVisibility(View.VISIBLE);
                    tvParcelas.setVisibility(View.VISIBLE);
                    totalFmPagto = total + (total * 0.05);
                    txtVlTot.setText(String.valueOf(totalFmPagto));
                }
            }
        });


        btnSalvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                salvarPedido();
            }
        });

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                adicionaItem();
            }
        });

        btnCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                calcPrazo();
            }
        });


        btnProcurar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ProcurarPedido();
            }
        });

    }

    private void salvarPedido() {
        String nome = txtNome.getText().toString();
        String cpf = txtCpf.getText().toString();

        try {
            if (!nome.equals("") && !cpf.equals("") && !(lsItens.size() == 0) && (rbtnVista.isChecked() || rbtnPrazo.isChecked())) {
                Cliente cliente = new Cliente(nome, cpf);
                if (rbtnVista.isChecked()) {
                    vista = true;
                } else {
                    vista = false;
                }
                Pedido pedido = new Pedido(idCdPed, cliente, lsItens, totalFmPagto, vista);
                lsPedidos.add(pedido);
                txtNome.setText("");
                txtCpf.setText("");
                txtItem.setText("");
                txtQtd.setText("0");
                txtVlUnit.setText("0");
                tvLsItens.setText("");
                rbtnVista.setChecked(false);
                rbtnPrazo.setChecked(false);
                txtParcelas.setText("0");
                tvLsParcelas.setText("");
                txtVlTot.setText("0");
                total = 0;
                idCdPed++;
                txtCdPedido.setText(String.valueOf(idCdPed));
                Toast.makeText(this, "Pedido de código " + (idCdPed - 1) + " foi cadastrado com sucesso!", Toast.LENGTH_LONG).show();


            } else {
                if (nome.equals("")) {
                    txtNome.setError("Informe o nome do cliente!");
                }
                if (cpf.equals("")) {
                    txtCpf.setError("Informe o CPF do cliente!");
                }
                if (rbtnVista.isChecked() == false && rbtnPrazo.isChecked() == false) {
                    Toast.makeText(this, "Escolha uma forma de pagamento!", Toast.LENGTH_LONG).show();
                }
                if (lsItens.size() == 0) {
                    Toast.makeText(this, "Insira pelo menos um item na lista de pedido!", Toast.LENGTH_LONG).show();
                }
            }

        } catch (Exception ex) {
            Log.e("ERRO", ex.getMessage());
        }
    }

    private void ProcurarPedido() {
        boolean existe = false;
        int cdExiste = 0;

        Integer cdPed = Integer.parseInt(txtCdPedido.getText().toString());

        if (cdPed.equals("")) {
            txtCdPedido.setText(idCdPed);
        }

        for (int i = 0; i < lsPedidos.size(); i++) {
            if (cdPed.equals(lsPedidos.get(i).getId())) {
                existe = true;
                cdExiste = i;
                break;
            }
        }

        try {
            String resultado = "";
            if (!cdPed.equals("") && !cdPed.equals(idCdPed)) {

                txtNome.setText(lsPedidos.get(cdExiste).getCliente().getNome());
                txtCpf.setText(lsPedidos.get(cdExiste).getCliente().getCpf());
                for (int i = 0; i < lsPedidos.get(cdExiste).getListItens().size(); i++) {
                    resultado += "Item: " + lsPedidos.get(cdExiste).getListItens().get(i).getNome() + " Quantidade: " + lsPedidos.get(cdExiste).getListItens().get(i).getQtn() + " Valor unitário: " + lsPedidos.get(cdExiste).getListItens().get(i).getVl_unitario() + "\n";
                }
                tvLsItens.setText(resultado);
                if (lsPedidos.get(cdExiste).isVista()) {
                    rbtnVista.setChecked(true);
                } else {
                    Toast.makeText(this, "prazo", Toast.LENGTH_SHORT).show();
                    rbtnPrazo.setChecked(true);
                    txtParcelas.setText(nrParc);
                    resultado += "--------------------------------------" + "\n";
                    double vlTotParc = (total + (total * 0.05)) / nrParc;
                    for (int i = 0; i <= nrParc; i++) {
                        resultado += "Parcela " + (i + 1) + "° custa: R$ " + vlTotParc + "\n";
                    }
                    resultado += "--------------------------------------" + "\n";
                    tvLsParcelas.setText(resultado);
                }
                total = lsPedidos.get(cdExiste).getVlTotalPagto();
                txtVlTot.setText(Double.toString(lsPedidos.get(cdExiste).getVlTotalPagto()));


            } else {

                if (cdPed <= 0) {
                    txtItem.setError("Informe um código válido!");
                }
                if (existe == false) {
                    Toast.makeText(this, "Não existe nenhum pedido com código " + cdPed + "!", Toast.LENGTH_SHORT).show();
                }
            }

        } catch (Exception ex) {
            Log.e("ERRO", ex.getMessage());
        }
    }

    private void adicionaItem() {
        if (txtVlUnit.getText().toString().equals("")) {
            txtVlUnit.setText("0");
        }
        if (txtQtd.getText().toString().equals("")) {
            txtQtd.setText("0");
        }

        String nm_item = txtItem.getText().toString();
        Double vl_Unit = Double.parseDouble(txtVlUnit.getText().toString());
        Integer qtn = Integer.parseInt(txtQtd.getText().toString());

        try {
            String resultado = tvLsItens.getText().toString();
            if (!nm_item.equals("") && !vl_Unit.equals("0") && !qtn.equals("0")) {
                resultado += "Item: " + nm_item + " Quantidade: " + qtn + " Valor unitário: " + vl_Unit + "\n";
                tvLsItens.setText(resultado);
                Item item = new Item(nm_item, qtn, vl_Unit);
                lsItens.add(item);
                total = 0.0;
                for (int i = 0; i < lsItens.size(); i++) {
                    total += lsItens.get(i).getTotal();
                }
                txtVlTot.setText(String.valueOf(total));
                Toast.makeText(this, "Item adicionado na lista com sucesso!", Toast.LENGTH_LONG).show();
            } else {
                if (nm_item.equals("")) {
                    txtItem.setError("Informe o nome do item!");
                }
                if (String.valueOf(qtn).startsWith("0") && !qtn.equals("0")) {
                    txtQtd.setError("Informe a quantidade do item!");
                }
                if (String.valueOf(vl_Unit).startsWith("0") && !vl_Unit.equals("0")) {
                    txtVlUnit.setError("Informe o valor unitário!");
                }
            }

        } catch (Exception ex) {
            Log.e("ERRO", ex.getMessage());
        }
    }

    private void calcPrazo() {

        if (txtParcelas.getText().toString().equals("")) {
            txtParcelas.setText("0");
        }

        Integer qtnParc = Integer.parseInt(txtParcelas.getText().toString());

        try {
            String resultado = tvLsParcelas.getText().toString();
            if (!qtnParc.equals("0")) {
                double vlTotParc = (total + (total * 0.05)) / qtnParc;
                resultado += "--------------------------------------" + "\n";
                for (int i = 1; i <= qtnParc; i++) {
                    resultado += "Parcela " + i + "° custa: R$ " + vlTotParc + "\n";
                }
                resultado += "--------------------------------------" + "\n";
                tvLsParcelas.setText(resultado);
                nrParc = qtnParc;
            } else {
                if (lsItens.size() == 0) {
                    Toast.makeText(this, "Insira pelo menos um item na lista de pedido!", Toast.LENGTH_LONG).show();
                }
                if (String.valueOf(qtnParc).startsWith("0") && !qtnParc.equals("0")) {
                    txtQtd.setError("Informe a quantidade de parcelas!");
                }
            }

        } catch (Exception ex) {
            Log.e("ERRO", ex.getMessage());
        }
    }
}